﻿namespace TX_SetupWizard
{
    partial class SetupWizardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SetupWizardForm));
            this.panel2 = new System.Windows.Forms.Panel();
            this.ButtonPre = new TX_Widget.BWButton();
            this.ButtonNext = new TX_Widget.BWButton();
            this.bwHoriTabcontrol1 = new TX_Widget.BWHoriTabcontrol();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.bwCheckBox3 = new TX_Widget.BWCheckBox();
            this.label27 = new System.Windows.Forms.Label();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.bwCheckBox12 = new TX_Widget.BWCheckBox();
            this.bwCheckBox2 = new TX_Widget.BWCheckBox();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.bwCheckBox1 = new TX_Widget.BWCheckBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.comboBox16 = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.comboBox15 = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.bwCheckBox6 = new TX_Widget.BWCheckBox();
            this.bwCheckBox9 = new TX_Widget.BWCheckBox();
            this.label18 = new System.Windows.Forms.Label();
            this.bwCheckBox7 = new TX_Widget.BWCheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.bwCheckBox5 = new TX_Widget.BWCheckBox();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.bwCheckBox4 = new TX_Widget.BWCheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.comboBox17 = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.comboBox18 = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.bwCheckBox8 = new TX_Widget.BWCheckBox();
            this.bwCheckBox10 = new TX_Widget.BWCheckBox();
            this.label32 = new System.Windows.Forms.Label();
            this.bwCheckBox11 = new TX_Widget.BWCheckBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.bwGlassButton1 = new TX_Widget.BWGlassButton();
            this.bwImageButton2 = new TX_Widget.BWImageButton();
            this.bwImageButton1 = new TX_Widget.BWImageButton();
            this.pictureBox0 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel2.SuspendLayout();
            this.bwHoriTabcontrol1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bwGlassButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bwImageButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bwImageButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.ButtonPre);
            this.panel2.Controls.Add(this.bwGlassButton1);
            this.panel2.Controls.Add(this.ButtonNext);
            this.panel2.Location = new System.Drawing.Point(0, 476);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(609, 48);
            this.panel2.TabIndex = 7;
            // 
            // ButtonPre
            // 
            this.ButtonPre.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonPre.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.ButtonPre.Location = new System.Drawing.Point(455, 16);
            this.ButtonPre.Name = "ButtonPre";
            this.ButtonPre.Size = new System.Drawing.Size(68, 23);
            this.ButtonPre.TabIndex = 9;
            this.ButtonPre.Text = "上一步";
            this.ButtonPre.UseVisualStyleBackColor = true;
            this.ButtonPre.Click += new System.EventHandler(this.ButtonPre_Click);
            // 
            // ButtonNext
            // 
            this.ButtonNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonNext.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.ButtonNext.Location = new System.Drawing.Point(527, 16);
            this.ButtonNext.Name = "ButtonNext";
            this.ButtonNext.Size = new System.Drawing.Size(68, 23);
            this.ButtonNext.TabIndex = 8;
            this.ButtonNext.Text = "下一步";
            this.ButtonNext.UseVisualStyleBackColor = true;
            this.ButtonNext.Click += new System.EventHandler(this.ButtonNext_Click);
            // 
            // bwHoriTabcontrol1
            // 
            this.bwHoriTabcontrol1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.bwHoriTabcontrol1.Controls.Add(this.tabPage1);
            this.bwHoriTabcontrol1.Controls.Add(this.tabPage2);
            this.bwHoriTabcontrol1.Controls.Add(this.tabPage3);
            this.bwHoriTabcontrol1.Controls.Add(this.tabPage4);
            this.bwHoriTabcontrol1.Controls.Add(this.tabPage5);
            this.bwHoriTabcontrol1.ItemSize = new System.Drawing.Size(100, 30);
            this.bwHoriTabcontrol1.Location = new System.Drawing.Point(0, 45);
            this.bwHoriTabcontrol1.Name = "bwHoriTabcontrol1";
            this.bwHoriTabcontrol1.SelectedIndex = 0;
            this.bwHoriTabcontrol1.Size = new System.Drawing.Size(609, 429);
            this.bwHoriTabcontrol1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.bwHoriTabcontrol1.TabIndex = 0;
            this.bwHoriTabcontrol1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.bwHoriTabcontrol1_Selecting);
            this.bwHoriTabcontrol1.SelectedIndexChanged += new System.EventHandler(this.bwHoriTabcontrol1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tabPage1.Controls.Add(this.pictureBox0);
            this.tabPage1.Controls.Add(this.bwCheckBox3);
            this.tabPage1.Controls.Add(this.label27);
            this.tabPage1.Controls.Add(this.comboBox12);
            this.tabPage1.Location = new System.Drawing.Point(4, 34);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(601, 391);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "模板设置";
            // 
            // bwCheckBox3
            // 
            this.bwCheckBox3.AutoSize = true;
            this.bwCheckBox3.BackColor = System.Drawing.Color.Transparent;
            this.bwCheckBox3.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.bwCheckBox3.Location = new System.Drawing.Point(228, 28);
            this.bwCheckBox3.Name = "bwCheckBox3";
            this.bwCheckBox3.Size = new System.Drawing.Size(75, 21);
            this.bwCheckBox3.TabIndex = 2;
            this.bwCheckBox3.Text = "详细设置";
            this.bwCheckBox3.UseVisualStyleBackColor = true;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(20, 32);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(65, 12);
            this.label27.TabIndex = 1;
            this.label27.Text = "模板选择：";
            // 
            // comboBox12
            // 
            this.comboBox12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Location = new System.Drawing.Point(88, 29);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(121, 20);
            this.comboBox12.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tabPage2.Controls.Add(this.bwCheckBox12);
            this.tabPage2.Controls.Add(this.bwCheckBox2);
            this.tabPage2.Controls.Add(this.comboBox11);
            this.tabPage2.Controls.Add(this.label26);
            this.tabPage2.Controls.Add(this.comboBox5);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.comboBox4);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.comboBox3);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.bwCheckBox1);
            this.tabPage2.Controls.Add(this.comboBox2);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.textBox1);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.comboBox1);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.pictureBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 34);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(601, 391);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "绘图样式";
            // 
            // bwCheckBox12
            // 
            this.bwCheckBox12.AutoSize = true;
            this.bwCheckBox12.BackColor = System.Drawing.Color.Transparent;
            this.bwCheckBox12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bwCheckBox12.Location = new System.Drawing.Point(275, 88);
            this.bwCheckBox12.Name = "bwCheckBox12";
            this.bwCheckBox12.Size = new System.Drawing.Size(99, 21);
            this.bwCheckBox12.TabIndex = 53;
            this.bwCheckBox12.Text = "是否使用参照";
            this.bwCheckBox12.UseVisualStyleBackColor = true;
            // 
            // bwCheckBox2
            // 
            this.bwCheckBox2.AutoSize = true;
            this.bwCheckBox2.BackColor = System.Drawing.Color.Transparent;
            this.bwCheckBox2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bwCheckBox2.Location = new System.Drawing.Point(275, 207);
            this.bwCheckBox2.Name = "bwCheckBox2";
            this.bwCheckBox2.Size = new System.Drawing.Size(111, 21);
            this.bwCheckBox2.TabIndex = 51;
            this.bwCheckBox2.Text = "钢筋表分类汇总";
            this.bwCheckBox2.UseVisualStyleBackColor = true;
            // 
            // comboBox11
            // 
            this.comboBox11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Items.AddRange(new object[] {
            "圆圈带直径",
            "圆圈不带直径",
            "直线带直径",
            "直线不带直径"});
            this.comboBox11.Location = new System.Drawing.Point(168, 208);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(84, 20);
            this.comboBox11.TabIndex = 50;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label26.Location = new System.Drawing.Point(107, 209);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(68, 17);
            this.label26.TabIndex = 49;
            this.label26.Text = "钢筋标注：";
            // 
            // comboBox5
            // 
            this.comboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "模型空间布局",
            "加长图纸空间",
            "全部图纸空间"});
            this.comboBox5.Location = new System.Drawing.Point(168, 87);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(84, 20);
            this.comboBox5.TabIndex = 48;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(107, 89);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 17);
            this.label10.TabIndex = 47;
            this.label10.Text = "布局设定：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(21, 85);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 21);
            this.label9.TabIndex = 46;
            this.label9.Text = "图框设置";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(20, 205);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 21);
            this.label8.TabIndex = 45;
            this.label8.Text = "钢筋设置";
            // 
            // comboBox4
            // 
            this.comboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "标注控制点",
            "标注圆弧点"});
            this.comboBox4.Location = new System.Drawing.Point(168, 145);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(84, 20);
            this.comboBox4.TabIndex = 44;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(107, 147);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 17);
            this.label7.TabIndex = 43;
            this.label7.Text = "标注样式：";
            // 
            // comboBox3
            // 
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "绘制示意构造",
            "绘制相关构造",
            "绘制上下构造"});
            this.comboBox3.Location = new System.Drawing.Point(168, 171);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(84, 20);
            this.comboBox3.TabIndex = 42;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(107, 173);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 17);
            this.label6.TabIndex = 41;
            this.label6.Text = "构造样式：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(18, 147);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 21);
            this.label5.TabIndex = 40;
            this.label5.Text = "钢束设置";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(19, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 21);
            this.label4.TabIndex = 39;
            this.label4.Text = "样式设置";
            // 
            // bwCheckBox1
            // 
            this.bwCheckBox1.AutoSize = true;
            this.bwCheckBox1.BackColor = System.Drawing.Color.Transparent;
            this.bwCheckBox1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bwCheckBox1.Location = new System.Drawing.Point(286, 46);
            this.bwCheckBox1.Name = "bwCheckBox1";
            this.bwCheckBox1.Size = new System.Drawing.Size(159, 21);
            this.bwCheckBox1.TabIndex = 38;
            this.bwCheckBox1.Text = "毫米制图（不勾为厘米）";
            this.bwCheckBox1.UseVisualStyleBackColor = true;
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "箭头",
            "建筑",
            "细线",
            "图块"});
            this.comboBox2.Location = new System.Drawing.Point(359, 21);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(84, 20);
            this.comboBox2.TabIndex = 37;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(272, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 17);
            this.label3.TabIndex = 36;
            this.label3.Text = "标注箭头样式：";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(168, 46);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(84, 21);
            this.textBox1.TabIndex = 35;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(107, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 17);
            this.label2.TabIndex = 34;
            this.label2.Text = "文字高度：";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "仿宋",
            "宋体",
            "FSDB"});
            this.comboBox1.Location = new System.Drawing.Point(168, 21);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(84, 20);
            this.comboBox1.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(107, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 17);
            this.label1.TabIndex = 32;
            this.label1.Text = "文字样式：";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tabPage3.Controls.Add(this.pictureBox2);
            this.tabPage3.Controls.Add(this.comboBox16);
            this.tabPage3.Controls.Add(this.label31);
            this.tabPage3.Controls.Add(this.comboBox15);
            this.tabPage3.Controls.Add(this.label30);
            this.tabPage3.Controls.Add(this.comboBox9);
            this.tabPage3.Controls.Add(this.label22);
            this.tabPage3.Controls.Add(this.comboBox8);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.bwCheckBox6);
            this.tabPage3.Controls.Add(this.bwCheckBox9);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.bwCheckBox7);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Location = new System.Drawing.Point(4, 34);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(601, 391);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "连续梁";
            // 
            // comboBox16
            // 
            this.comboBox16.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox16.FormattingEnabled = true;
            this.comboBox16.Items.AddRange(new object[] {
            "腹板一次变化A",
            "腹板一次变化B",
            "腹板一次变化C",
            "腹板两次变化"});
            this.comboBox16.Location = new System.Drawing.Point(205, 93);
            this.comboBox16.Name = "comboBox16";
            this.comboBox16.Size = new System.Drawing.Size(92, 20);
            this.comboBox16.TabIndex = 71;
            this.comboBox16.SelectedIndexChanged += new System.EventHandler(this.comboBox16_SelectedIndexChanged);
            this.comboBox16.MouseEnter += new System.EventHandler(this.comboBox16_MouseEnter);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.Location = new System.Drawing.Point(117, 95);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(92, 17);
            this.label31.TabIndex = 70;
            this.label31.Text = "平面腹板控制：";
            // 
            // comboBox15
            // 
            this.comboBox15.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox15.FormattingEnabled = true;
            this.comboBox15.Items.AddRange(new object[] {
            "倒角平行",
            "倒角收拢"});
            this.comboBox15.Location = new System.Drawing.Point(205, 68);
            this.comboBox15.Name = "comboBox15";
            this.comboBox15.Size = new System.Drawing.Size(92, 20);
            this.comboBox15.TabIndex = 71;
            this.comboBox15.SelectedIndexChanged += new System.EventHandler(this.comboBox15_SelectedIndexChanged);
            this.comboBox15.MouseEnter += new System.EventHandler(this.comboBox15_MouseEnter);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label30.Location = new System.Drawing.Point(117, 70);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(92, 17);
            this.label30.TabIndex = 70;
            this.label30.Text = "立面倒角控制：";
            // 
            // comboBox9
            // 
            this.comboBox9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "横梁范围不设",
            "横梁范围延伸"});
            this.comboBox9.Location = new System.Drawing.Point(205, 178);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(92, 20);
            this.comboBox9.TabIndex = 69;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.Location = new System.Drawing.Point(117, 181);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(92, 17);
            this.label22.TabIndex = 68;
            this.label22.Text = "顶底横向钢筋：";
            // 
            // comboBox8
            // 
            this.comboBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "一个小箍筋",
            "大小双箍筋",
            "交叉双箍筋A",
            "交叉双箍筋B",
            "箍筋加拉筋A",
            "箍筋加拉筋B"});
            this.comboBox8.Location = new System.Drawing.Point(205, 204);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(92, 20);
            this.comboBox8.TabIndex = 67;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.Location = new System.Drawing.Point(117, 206);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(92, 17);
            this.label21.TabIndex = 66;
            this.label21.Text = "腹板箍筋控制：";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(30, 174);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(74, 21);
            this.label19.TabIndex = 63;
            this.label19.Text = "钢筋设置";
            // 
            // bwCheckBox6
            // 
            this.bwCheckBox6.AutoSize = true;
            this.bwCheckBox6.BackColor = System.Drawing.Color.Transparent;
            this.bwCheckBox6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bwCheckBox6.Location = new System.Drawing.Point(318, 180);
            this.bwCheckBox6.Name = "bwCheckBox6";
            this.bwCheckBox6.Size = new System.Drawing.Size(135, 21);
            this.bwCheckBox6.TabIndex = 62;
            this.bwCheckBox6.Text = "平面绘制全部纵向筋";
            this.bwCheckBox6.UseVisualStyleBackColor = true;
            // 
            // bwCheckBox9
            // 
            this.bwCheckBox9.AutoSize = true;
            this.bwCheckBox9.BackColor = System.Drawing.Color.Transparent;
            this.bwCheckBox9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bwCheckBox9.Location = new System.Drawing.Point(117, 130);
            this.bwCheckBox9.Name = "bwCheckBox9";
            this.bwCheckBox9.Size = new System.Drawing.Size(111, 21);
            this.bwCheckBox9.TabIndex = 62;
            this.bwCheckBox9.Text = "平面绘腹板钢束";
            this.bwCheckBox9.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(30, 127);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(74, 21);
            this.label18.TabIndex = 61;
            this.label18.Text = "钢束设置";
            // 
            // bwCheckBox7
            // 
            this.bwCheckBox7.AutoSize = true;
            this.bwCheckBox7.BackColor = System.Drawing.Color.Transparent;
            this.bwCheckBox7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bwCheckBox7.Location = new System.Drawing.Point(117, 27);
            this.bwCheckBox7.Name = "bwCheckBox7";
            this.bwCheckBox7.Size = new System.Drawing.Size(75, 21);
            this.bwCheckBox7.TabIndex = 59;
            this.bwCheckBox7.Text = "分跨绘制";
            this.bwCheckBox7.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(30, 24);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(74, 21);
            this.label17.TabIndex = 58;
            this.label17.Text = "绘图设置";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(30, 69);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(74, 21);
            this.label15.TabIndex = 56;
            this.label15.Text = "构造设置";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tabPage4.Controls.Add(this.pictureBox3);
            this.tabPage4.Controls.Add(this.bwCheckBox5);
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Controls.Add(this.comboBox14);
            this.tabPage4.Controls.Add(this.label29);
            this.tabPage4.Controls.Add(this.comboBox6);
            this.tabPage4.Controls.Add(this.label13);
            this.tabPage4.Controls.Add(this.textBox2);
            this.tabPage4.Controls.Add(this.label12);
            this.tabPage4.Controls.Add(this.bwCheckBox4);
            this.tabPage4.Controls.Add(this.label11);
            this.tabPage4.Location = new System.Drawing.Point(4, 34);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(601, 391);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "高架总图";
            // 
            // bwCheckBox5
            // 
            this.bwCheckBox5.AutoSize = true;
            this.bwCheckBox5.BackColor = System.Drawing.Color.Transparent;
            this.bwCheckBox5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bwCheckBox5.Location = new System.Drawing.Point(98, 128);
            this.bwCheckBox5.Name = "bwCheckBox5";
            this.bwCheckBox5.Size = new System.Drawing.Size(123, 21);
            this.bwCheckBox5.TabIndex = 41;
            this.bwCheckBox5.Text = "下部结构绘制虚线";
            this.bwCheckBox5.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(16, 102);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(74, 21);
            this.label14.TabIndex = 39;
            this.label14.Text = "绘图控制";
            // 
            // comboBox14
            // 
            this.comboBox14.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.Items.AddRange(new object[] {
            "不标注",
            "水平标注",
            "竖直标注",
            "直接标注"});
            this.comboBox14.Location = new System.Drawing.Point(183, 44);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(86, 20);
            this.comboBox14.TabIndex = 38;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label29.Location = new System.Drawing.Point(93, 47);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(92, 17);
            this.label29.TabIndex = 37;
            this.label29.Text = "桥墩高度控制：";
            // 
            // comboBox6
            // 
            this.comboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "不标注",
            "水平标注",
            "竖直标注",
            "直接标注"});
            this.comboBox6.Location = new System.Drawing.Point(158, 157);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(84, 20);
            this.comboBox6.TabIndex = 38;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(96, 158);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 17);
            this.label13.TabIndex = 37;
            this.label13.Text = "桩基标注：";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(183, 17);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(86, 21);
            this.textBox2.TabIndex = 36;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(93, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 17);
            this.label12.TabIndex = 35;
            this.label12.Text = "承台顶距地面：";
            // 
            // bwCheckBox4
            // 
            this.bwCheckBox4.AutoSize = true;
            this.bwCheckBox4.BackColor = System.Drawing.Color.Transparent;
            this.bwCheckBox4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bwCheckBox4.Location = new System.Drawing.Point(98, 102);
            this.bwCheckBox4.Name = "bwCheckBox4";
            this.bwCheckBox4.Size = new System.Drawing.Size(123, 21);
            this.bwCheckBox4.TabIndex = 34;
            this.bwCheckBox4.Text = "表格输出桥墩信息";
            this.bwCheckBox4.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(16, 14);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(58, 21);
            this.label11.TabIndex = 33;
            this.label11.Text = "立面图";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tabPage5.Controls.Add(this.pictureBox4);
            this.tabPage5.Location = new System.Drawing.Point(4, 34);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(601, 391);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "完成";
            // 
            // comboBox7
            // 
            this.comboBox7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "腹板一次变化A",
            "腹板一次变化B",
            "腹板一次变化C",
            "腹板两次变化"});
            this.comboBox7.Location = new System.Drawing.Point(205, 93);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(92, 20);
            this.comboBox7.TabIndex = 71;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(117, 95);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(92, 17);
            this.label16.TabIndex = 70;
            this.label16.Text = "平面腹板控制：";
            // 
            // comboBox10
            // 
            this.comboBox10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Items.AddRange(new object[] {
            "倒角平行",
            "倒角收拢"});
            this.comboBox10.Location = new System.Drawing.Point(205, 68);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(92, 20);
            this.comboBox10.TabIndex = 71;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(117, 70);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(92, 17);
            this.label20.TabIndex = 70;
            this.label20.Text = "立面倒角控制：";
            // 
            // comboBox17
            // 
            this.comboBox17.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox17.FormattingEnabled = true;
            this.comboBox17.Items.AddRange(new object[] {
            "横梁范围不设",
            "横梁范围延伸"});
            this.comboBox17.Location = new System.Drawing.Point(205, 178);
            this.comboBox17.Name = "comboBox17";
            this.comboBox17.Size = new System.Drawing.Size(92, 20);
            this.comboBox17.TabIndex = 69;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.Location = new System.Drawing.Point(117, 181);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(92, 17);
            this.label23.TabIndex = 68;
            this.label23.Text = "顶底横向钢筋：";
            // 
            // comboBox18
            // 
            this.comboBox18.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox18.FormattingEnabled = true;
            this.comboBox18.Items.AddRange(new object[] {
            "标注控制点",
            "标注圆弧点"});
            this.comboBox18.Location = new System.Drawing.Point(205, 204);
            this.comboBox18.Name = "comboBox18";
            this.comboBox18.Size = new System.Drawing.Size(92, 20);
            this.comboBox18.TabIndex = 67;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.Location = new System.Drawing.Point(117, 206);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(92, 17);
            this.label24.TabIndex = 66;
            this.label24.Text = "腹板箍筋控制：";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.Location = new System.Drawing.Point(30, 174);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(74, 21);
            this.label25.TabIndex = 63;
            this.label25.Text = "钢筋设置";
            // 
            // bwCheckBox8
            // 
            this.bwCheckBox8.AutoSize = true;
            this.bwCheckBox8.BackColor = System.Drawing.Color.Transparent;
            this.bwCheckBox8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bwCheckBox8.Location = new System.Drawing.Point(318, 180);
            this.bwCheckBox8.Name = "bwCheckBox8";
            this.bwCheckBox8.Size = new System.Drawing.Size(135, 21);
            this.bwCheckBox8.TabIndex = 62;
            this.bwCheckBox8.Text = "平面绘制全部纵向筋";
            this.bwCheckBox8.UseVisualStyleBackColor = true;
            // 
            // bwCheckBox10
            // 
            this.bwCheckBox10.AutoSize = true;
            this.bwCheckBox10.BackColor = System.Drawing.Color.Transparent;
            this.bwCheckBox10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bwCheckBox10.Location = new System.Drawing.Point(117, 130);
            this.bwCheckBox10.Name = "bwCheckBox10";
            this.bwCheckBox10.Size = new System.Drawing.Size(111, 21);
            this.bwCheckBox10.TabIndex = 62;
            this.bwCheckBox10.Text = "平面绘腹板钢束";
            this.bwCheckBox10.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label32.Location = new System.Drawing.Point(30, 127);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(74, 21);
            this.label32.TabIndex = 61;
            this.label32.Text = "钢束设置";
            // 
            // bwCheckBox11
            // 
            this.bwCheckBox11.AutoSize = true;
            this.bwCheckBox11.BackColor = System.Drawing.Color.Transparent;
            this.bwCheckBox11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bwCheckBox11.Location = new System.Drawing.Point(117, 27);
            this.bwCheckBox11.Name = "bwCheckBox11";
            this.bwCheckBox11.Size = new System.Drawing.Size(75, 21);
            this.bwCheckBox11.TabIndex = 59;
            this.bwCheckBox11.Text = "分跨绘制";
            this.bwCheckBox11.UseVisualStyleBackColor = true;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label33.Location = new System.Drawing.Point(30, 24);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(74, 21);
            this.label33.TabIndex = 58;
            this.label33.Text = "绘图设置";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label34.Location = new System.Drawing.Point(30, 69);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(74, 21);
            this.label34.TabIndex = 56;
            this.label34.Text = "构造设置";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(208, 1);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(167, 43);
            this.pictureBox6.TabIndex = 8;
            this.pictureBox6.TabStop = false;
            // 
            // bwGlassButton1
            // 
            this.bwGlassButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bwGlassButton1.BackColor = System.Drawing.Color.Transparent;
            this.bwGlassButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bwGlassButton1.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.bwGlassButton1.Location = new System.Drawing.Point(26, 16);
            this.bwGlassButton1.Name = "bwGlassButton1";
            this.bwGlassButton1.Size = new System.Drawing.Size(163, 23);
            this.bwGlassButton1.TabIndex = 7;
            this.bwGlassButton1.TabStop = false;
            this.bwGlassButton1.Text = "官网：www.bridgewise.net";
            this.bwGlassButton1.ToolTipText = null;
            this.bwGlassButton1.Click += new System.EventHandler(this.bwGlassButton1_Click);
            // 
            // bwImageButton2
            // 
            this.bwImageButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bwImageButton2.BackColor = System.Drawing.Color.Transparent;
            this.bwImageButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bwImageButton2.DownImage = ((System.Drawing.Image)(resources.GetObject("bwImageButton2.DownImage")));
            this.bwImageButton2.HoverImage = ((System.Drawing.Image)(resources.GetObject("bwImageButton2.HoverImage")));
            this.bwImageButton2.Location = new System.Drawing.Point(549, 11);
            this.bwImageButton2.Name = "bwImageButton2";
            this.bwImageButton2.NormalImage = ((System.Drawing.Image)(resources.GetObject("bwImageButton2.NormalImage")));
            this.bwImageButton2.Size = new System.Drawing.Size(23, 19);
            this.bwImageButton2.TabIndex = 6;
            this.bwImageButton2.TabStop = false;
            this.bwImageButton2.ToolTipText = null;
            this.bwImageButton2.Click += new System.EventHandler(this.bwImageButton2_Click);
            // 
            // bwImageButton1
            // 
            this.bwImageButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bwImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bwImageButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bwImageButton1.DownImage = ((System.Drawing.Image)(resources.GetObject("bwImageButton1.DownImage")));
            this.bwImageButton1.HoverImage = ((System.Drawing.Image)(resources.GetObject("bwImageButton1.HoverImage")));
            this.bwImageButton1.Location = new System.Drawing.Point(578, 11);
            this.bwImageButton1.Name = "bwImageButton1";
            this.bwImageButton1.NormalImage = ((System.Drawing.Image)(resources.GetObject("bwImageButton1.NormalImage")));
            this.bwImageButton1.Size = new System.Drawing.Size(24, 19);
            this.bwImageButton1.TabIndex = 5;
            this.bwImageButton1.TabStop = false;
            this.bwImageButton1.ToolTipText = null;
            this.bwImageButton1.Click += new System.EventHandler(this.bwImageButton1_Click);
            // 
            // pictureBox0
            // 
            this.pictureBox0.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox0.Location = new System.Drawing.Point(22, 72);
            this.pictureBox0.Name = "pictureBox0";
            this.pictureBox0.Size = new System.Drawing.Size(558, 293);
            this.pictureBox0.TabIndex = 3;
            this.pictureBox0.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Location = new System.Drawing.Point(22, 234);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(557, 145);
            this.pictureBox1.TabIndex = 52;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.Location = new System.Drawing.Point(22, 230);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(559, 149);
            this.pictureBox2.TabIndex = 72;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox3.Location = new System.Drawing.Point(20, 178);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(548, 207);
            this.pictureBox3.TabIndex = 42;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox4.Location = new System.Drawing.Point(3, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(592, 385);
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // SetupWizardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(607, 526);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.bwImageButton2);
            this.Controls.Add(this.bwImageButton1);
            this.Controls.Add(this.bwHoriTabcontrol1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SetupWizardForm";
            this.Text = "桥梁智绘向导";
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.SetDirectionForm_MouseUp);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.SetDirectionForm_MouseDown);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SetDirectionForm_FormClosing);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SetDirectionForm_MouseMove);
            this.panel2.ResumeLayout(false);
            this.bwHoriTabcontrol1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bwGlassButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bwImageButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bwImageButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private TX_Widget.BWImageButton bwImageButton2;
        private TX_Widget.BWImageButton bwImageButton1;
        private TX_Widget.BWGlassButton bwGlassButton1;
        private TX_Widget.BWButton ButtonNext;
        private TX_Widget.BWButton ButtonPre;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private TX_Widget.BWHoriTabcontrol bwHoriTabcontrol1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label12;
        private TX_Widget.BWCheckBox bwCheckBox4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label19;
        private TX_Widget.BWCheckBox bwCheckBox9;
        private System.Windows.Forms.Label label18;
        private TX_Widget.BWCheckBox bwCheckBox7;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private TX_Widget.BWCheckBox bwCheckBox2;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private TX_Widget.BWCheckBox bwCheckBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox comboBox12;
        private TX_Widget.BWCheckBox bwCheckBox3;
        private System.Windows.Forms.Panel panel2;
        private TX_Widget.BWCheckBox bwCheckBox5;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox comboBox16;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox comboBox15;
        private System.Windows.Forms.Label label30;
        private TX_Widget.BWCheckBox bwCheckBox6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBox17;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox comboBox18;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private TX_Widget.BWCheckBox bwCheckBox8;
        private TX_Widget.BWCheckBox bwCheckBox10;
        private System.Windows.Forms.Label label32;
        private TX_Widget.BWCheckBox bwCheckBox11;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox0;
        private System.Windows.Forms.PictureBox pictureBox6;
        private TX_Widget.BWCheckBox bwCheckBox12;
    }
}