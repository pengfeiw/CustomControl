﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TX_Widget;
using Microsoft.Win32;
using System.Text.RegularExpressions;
using System.Threading;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;

namespace TX_SetupWizard
{
    public partial class SetupWizardForm : Form
    {
        private int currentSelectTab = 0;
        public SetupWizardForm()
        {
            InitializeComponent();
            this.CenterToScreen();
            currentSelectTab = this.bwHoriTabcontrol1.SelectedIndex;
            bwHoriTabcontrol1_SelectedIndexChanged(null, null);
            XmlRW.LoadFromFile(this, map);
            this.bwCheckBox3.Checked = true;
            this.panel2.BackColor = Color.FromArgb(250, 250, 250);
            InitTabToPicboxMap();
            cotrolInit();
        }

        public static Dictionary<TabPage, PictureBox> tabToPicturebox = new Dictionary<TabPage, PictureBox>();

        private void InitTabToPicboxMap()
        {
            for (int i = 0; i < this.bwHoriTabcontrol1.TabPages.Count; i++)
            {
                List<Control> ctrs = XmlRW.GetControls(this.bwHoriTabcontrol1.TabPages[i]);
                foreach (Control ctr in ctrs)
                {
                    if (ctr is PictureBox)
                        tabToPicturebox.Add(this.bwHoriTabcontrol1.TabPages[i], (PictureBox)ctr);
                }
            }
        }

        private void ShowImage(ComboBox comboBox)
        {
            Control ctrParent = comboBox.Parent;
            PictureBox picBox = null;
            if (ctrParent is TabPage)
                picBox = tabToPicturebox[(TabPage)ctrParent];
            String imagePath = comboBox.Name + "_" + "Img" + Convert.ToString(comboBox.SelectedIndex);
            Image img = (Image)Resource1.ResourceManager.GetObject(imagePath);
            picBox.Image = img;
        }


        //初始化comboBox和checkBox.
        private void cotrolInit()
        {
            ModelInit();
            List<Control> ctrs = XmlRW.GetControls(this);
            foreach (Control ctr in ctrs)
            {
                if (ctr is ComboBox && ((ComboBox)ctr).Items.Count > 0)
                {
                    ((ComboBox)ctr).SelectedIndex = 0;
                }
                else if (ctr is CheckBox)
                {
                    ((CheckBox)ctr).Checked = true;
                }
            }
        }

        //“||”符号前面是文件相对路径，后面是相应节点的XPath。
        //文件相对路径中，用‘|’表示文件夹包含关系。例如“TX_Tem | doc.xml”表示TX_Tem文件夹下的doc.xml文件。
        //当文件名是“连续梁.tx_连续梁”时对应的是等高变高悬浇。
        private static Dictionary<string, string> map = new Dictionary<string, string>()
        {
            //常规
            {"comboBox2", "TX_Option.xml || /Form/Para[@name='comboBox1']"},   //标注箭头样式
            {"textBox1", "TX_Option.xml || /Form/Para[@name='textBox20']"},    //文字高度
            {"bwCheckBox1", "TX_Option.xml || /Form/Para[@name='checkBox2']"},  //毫米制图（不勾为厘米）
            {"comboBox3", "TX_Option.xml || /Form/Para[@name='comboBox6']"},   //大样绘制样式
            {"comboBox4", "TX_Option.xml || /Form/Para[@name='comboBox10']"},  //标注样式
            {"bwCheckBox2", "TX_Option.xml || /Form/Para[@name='checkBox102']"}, //表格分类汇总
            {"comboBox5", "TX_FrameOption.frame || /Form/Para[@name='comboBoxFrameLayout']"},  //图框布局
            {"bwCheckBox12", "TX_FrameOption.frame || /Form/Para[@name='checkBox3']"},

            //高架总图
            {"textBox2", "TX_Template\\高架总图.tx_高架总图 || /Entity/Form[@name='出图设置']/Para[@name='textBox2']"},   //承台顶距地面
            {"comboBox6", "TX_Template\\高架总图.tx_高架总图 || /Entity/Form[@name='出图设置']/Para[@name='comboBox1']"},   //桩基标注
            {"bwCheckBox5", "TX_Template\\高架总图.tx_高架总图 || /Entity/Form[@name='出图设置']/Para[@name='checkBox24']"},   //下部结构虚线
            {"bwCheckBox4", "TX_Template\\高架总图.tx_高架总图 || /Entity/Form[@name='出图设置']/Para[@name='checkBox23']"},   //表格输出桥墩信息
            {"comboBox14", "TX_Template\\高架总图.tx_高架总图 || /Entity/Form[@name='出图设置']/Para[@name='comboBox3']"},   //桥墩高度控制
            

            //连续梁
            {"bwCheckBox7", "TX_Template\\连续梁.tx_连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox18']"},   //构造图分跨绘制
            {"bwCheckBox8", "TX_Template\\连续梁.tx_连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox64']"},   //构造图绘制齿块
            {"bwCheckBox9", "TX_Template\\连续梁.tx_连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox52']"},   //平面绘腹板钢束
            {"comboBox7", "TX_Template\\连续梁.tx_连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='comboBox401']"},   //标准宽箍筋
            {"comboBox8", "TX_Template\\连续梁.tx_连续梁 || /Entity/Form[@name='钢筋数据']/Para[@name='comboBox8']"},   //加宽段箍筋
            {"comboBox9", "TX_Template\\连续梁.tx_连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='comboBox403']"},   //顶底缘钢筋
            {"comboBox10", "TX_Template\\连续梁.tx_连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='comboBox4']"},   //顶底缘钢筋
            {"bwCheckBox10", "TX_Template\\连续梁.tx_连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox422']"},   //腹板纵向筋置外侧
        };

        private static List<SpecialMap> specialMap = new List<SpecialMap>()
        {
            //文字样式
            new SpecialMap("comboBox1", "0", "TX_Option.xml || /Form/Para[@name='textBox11']", "仿宋字"),
            new SpecialMap("comboBox1", "0", "TX_Option.xml || /Form/Para[@name='textBox12']", "仿宋"),
            new SpecialMap("comboBox1", "0", "TX_Option.xml || /Form/Para[@name='textBox18']", "常规"),
            new SpecialMap("comboBox1", "0", "TX_Option.xml || /Form/Para[@name='textBox24']", "0.75"),
            new SpecialMap("comboBox1", "0", "TX_Option.xml || /Form/Para[@name='checkBoxFont']", "False"),

            new SpecialMap("comboBox1", "1", "TX_Option.xml || /Form/Para[@name='textBox11']", "宋体字"),
            new SpecialMap("comboBox1", "1", "TX_Option.xml || /Form/Para[@name='textBox12']", "宋体"),
            new SpecialMap("comboBox1", "1", "TX_Option.xml || /Form/Para[@name='textBox18']", "常规"),
            new SpecialMap("comboBox1", "1", "TX_Option.xml || /Form/Para[@name='textBox24']", "0.75"),
            new SpecialMap("comboBox1", "1", "TX_Option.xml || /Form/Para[@name='checkBoxFont']", "False"),

            new SpecialMap("comboBox1", "2", "TX_Option.xml || /Form/Para[@name='textBox11']", "FS"),
            new SpecialMap("comboBox1", "2", "TX_Option.xml || /Form/Para[@name='textBox12']", "fsdb_e.shx"),
            new SpecialMap("comboBox1", "2", "TX_Option.xml || /Form/Para[@name='textBox18']", "tjhzf.shx"),
            new SpecialMap("comboBox1", "2", "TX_Option.xml || /Form/Para[@name='textBox24']", "0.7"),
            new SpecialMap("comboBox1", "2", "TX_Option.xml || /Form/Para[@name='checkBoxFont']", "True"),

            //钢筋标注
            new SpecialMap("comboBox11", "0", "TX_Option.xml || /Form/Para[@name='checkBox22']", "True"),
            new SpecialMap("comboBox11", "0", "TX_Option.xml || /Form/Para[@name='checkBox17']", "True"),

            new SpecialMap("comboBox11", "1", "TX_Option.xml || /Form/Para[@name='checkBox22']", "False"),
            new SpecialMap("comboBox11", "1", "TX_Option.xml || /Form/Para[@name='checkBox17']", "True"),
            
            new SpecialMap("comboBox11", "2", "TX_Option.xml || /Form/Para[@name='checkBox22']", "True"),
            new SpecialMap("comboBox11", "2", "TX_Option.xml || /Form/Para[@name='checkBox17']", "False"),

            new SpecialMap("comboBox11", "3", "TX_Option.xml || /Form/Para[@name='checkBox22']", "False"),
            new SpecialMap("comboBox11", "3", "TX_Option.xml || /Form/Para[@name='checkBox17']", "False"),

            //立面倒角控制
            new SpecialMap("comboBox15", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox22']", "True"),
            new SpecialMap("comboBox15", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox23']", "True"),
            new SpecialMap("comboBox15", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox49']", "True"),
            new SpecialMap("comboBox15", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox50']", "True"),

            new SpecialMap("comboBox15", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox22']", "False"),
            new SpecialMap("comboBox15", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox23']", "False"),
            new SpecialMap("comboBox15", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox49']", "False"),
            new SpecialMap("comboBox15", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox50']", "False"),

            new SpecialMap("comboBox15", "0", "TX_Template\\变高连续梁.tx_变高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox22']", "True"),
            new SpecialMap("comboBox15", "0", "TX_Template\\变高连续梁.tx_变高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox23']", "True"),
            new SpecialMap("comboBox15", "0", "TX_Template\\变高连续梁.tx_变高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox49']", "True"),
            new SpecialMap("comboBox15", "0", "TX_Template\\变高连续梁.tx_变高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox50']", "True"),

            new SpecialMap("comboBox15", "1", "TX_Template\\变高连续梁.tx_变高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox22']", "False"),
            new SpecialMap("comboBox15", "1", "TX_Template\\变高连续梁.tx_变高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox23']", "False"),
            new SpecialMap("comboBox15", "1", "TX_Template\\变高连续梁.tx_变高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox49']", "False"),
            new SpecialMap("comboBox15", "1", "TX_Template\\变高连续梁.tx_变高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='checkBox50']", "False"),

            //顶底缘横向钢筋
            new SpecialMap("comboBox9", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='comboBox403']", "0"),
            new SpecialMap("comboBox9", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='comboBox403']", "1"),
            
            new SpecialMap("comboBox9", "0", "TX_Template\\变高连续梁.tx_变高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='comboBox403']", "0"),
            new SpecialMap("comboBox9", "1", "TX_Template\\变高连续梁.tx_变高连续梁 || /Entity/Form[@name='绘图设置']/Para[@name='comboBox403']", "1"),

            ///平面腹板控制
            //等高
            //一次变化A
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox5']", "250"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox6']", "250"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox10']", "2500"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox9']", "2500"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox18']", "0"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox17']", "0"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='checkBox3']", "False"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='checkBox4']", "False"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox22']", "2500"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox24']", "200"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox37']", "2500"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox26']", "200"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox23']", "2500"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox25']", "200"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox38']", "2500"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox27']", "200"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='comboBox1']", "0"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='comboBox2']", "0"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox28']", "1500"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox33']", "300"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox34']", "150"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox29']", "1500"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox35']", "300"),
            new SpecialMap("comboBox16", "0", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox36']", "150"),
            //一次变化B
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox5']", "500"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox6']", "500"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox10']", "3000"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox9']", "3000"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox18']", "3500"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox17']", "3500"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='checkBox3']", "False"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='checkBox4']", "False"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox22']", "600"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox24']", "300"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox37']", "0"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox26']", "0"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox23']", "600"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox25']", "300"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox38']", "0"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox27']", "0"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='comboBox1']", "0"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='comboBox2']", "0"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox28']", "0"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox33']", "300"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox34']", "150"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox29']", "0"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox35']", "300"),
            new SpecialMap("comboBox16", "1", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox36']", "150"),
            //一次变化C
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox5']", "500"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox6']", "500"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox10']", "4000"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox9']", "4000"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox18']", "0"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox17']", "0"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='checkBox3']", "True"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='checkBox4']", "True"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox22']", "600"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox24']", "300"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox37']", "0"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox26']", "0"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox23']", "600"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox25']", "300"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox38']", "0"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox27']", "0"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='comboBox1']", "2"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='comboBox2']", "2"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox28']", "600"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox33']", "300"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox34']", "150"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox29']", "600"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox35']", "300"),
            new SpecialMap("comboBox16", "2", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox36']", "150"),
            //两次变化
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox5']", "500"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox6']", "500"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox10']", "4000"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox9']", "4000"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox18']", "4500"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox17']", "4500"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='checkBox3']", "False"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='checkBox4']", "False"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox22']", "1500"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox24']", "200"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox37']", "1500"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox26']", "200"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox23']", "1500"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox25']", "200"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox38']", "1500"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox27']", "200"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='comboBox1']", "2"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='comboBox2']", "2"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox28']", "1500"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox33']", "300"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox34']", "150"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox29']", "1500"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox35']", "300"),
            new SpecialMap("comboBox16", "3", "TX_Template\\等高连续梁.tx_等高连续梁 || /Entity/Form[@name='纵向数据']/Para[@name='textBox36']", "150")

            //变高
        };

        internal static List<SpecialMap> getSpecialMap(string ctrName, string ctrValue)
        {
            List<SpecialMap> sm = new List<SpecialMap>();
            foreach (var map in specialMap)
            {
                if (map.wizard_CtrName == ctrName && map.wizard_CtrValue == ctrValue)
                    sm.Add(map);
            }
            return sm;
        }

        private void bwImageButton1_Click(object sender, EventArgs e)
        {
            if (BWMessageBox.Show(this, "确定放弃所有修改并退出设置向导吗？", "退出", BWMessageBoxIcon.Question, BWMessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                windowCloseCarton();
                // 关闭所有的线程
                this.Dispose();
                this.Close();
            }
        }

        private void bwImageButton2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void bwGlassButton1_Click(object sender, EventArgs e)
        {
            RegistryKey key = Registry.ClassesRoot.OpenSubKey(@"http\shell\open\command\");
            string s = key.GetValue("").ToString();

            Regex reg = new Regex("\"([^\"]+)\"");
            MatchCollection matchs = reg.Matches(s);

            string filename = "";
            if (matchs.Count > 0)
            {
                filename = matchs[0].Groups[1].Value;
                System.Diagnostics.Process.Start(filename, "www.bridgewise.net");
            }
        }

        //结束窗体时特效
        private void windowCloseCarton()
        {
            int x = this.Location.X;
            int y = this.Location.Y;
            this.MinimumSize = new Size(0, 0);
            while (this.Width > SystemInformation.MinWindowTrackSize.Width || this.Height > SystemInformation.MinWindowTrackSize.Height)
            {
                if (this.Height > SystemInformation.MinWindowTrackSize.Height)
                {
                    this.Location = new System.Drawing.Point(x, y += 15);//设置窗体位置
                    this.Size = new Size(this.Width, this.Height -= 25);//设置窗体大小
                    this.Opacity -= 0.04;//设置窗体透明度递减
                }
                else if (this.Width > SystemInformation.MinWindowTrackSize.Width)
                {
                    this.Size = new Size(this.Width -= 25, this.Height);
                    //this.Location = new System.Drawing.Point(x + 12, y);
                    this.Opacity -= 0.04;//设置窗体透明度递减
                }
                Thread.Sleep(10);  // 线程休眠10毫秒
            }
        }

        //通过mouse事件，移动窗口。
        private bool isMouseDown;
        private bool isMouseUp { get { return !isMouseDown; } }
        private Point FormLocation; //form的location 
        private Point mouseOffset; //鼠标的按下位置
        private void SetDirectionForm_MouseMove(object sender, MouseEventArgs e)
        {
            int _x = 0;
            int _y = 0;
            if (isMouseDown)
            {
                Point pt = Control.MousePosition;
                _x = mouseOffset.X - pt.X;
                _y = mouseOffset.Y - pt.Y;

                this.Location = new Point(FormLocation.X - _x, FormLocation.Y - _y);
            }
        }

        private void SetDirectionForm_MouseUp(object sender, MouseEventArgs e)
        {
            isMouseDown = false;
        }

        private void SetDirectionForm_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isMouseDown = true;
                FormLocation = this.Location;
                mouseOffset = Control.MousePosition;
            }
        }

        private void bwHoriTabcontrol1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            int selectedTab = bwHoriTabcontrol1.SelectedIndex;
            if (currentSelectTab != selectedTab)
            {
                bwHoriTabcontrol1.SelectTab(currentSelectTab);
            }
        }

        private void bwHoriTabcontrol1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.bwHoriTabcontrol1.SelectedIndex == 0)
            {
                ButtonPre.Hide();
                ButtonNext.Text = "下一步";
            }
            else if (this.bwHoriTabcontrol1.SelectedIndex == this.bwHoriTabcontrol1.TabCount - 1)
            {
                ButtonPre.Show();
                ButtonNext.Text = "完成";
            }
            else
            {
                ButtonPre.Show();
                ButtonNext.Text = "下一步";
            }
        }

        private static bool showMessageBox = false;
        private void ButtonNext_Click(object sender, EventArgs e)
        {
            if (this.ButtonNext.Text == "下一步")
            {
                if (this.bwCheckBox3.Checked == false && this.comboBox12.SelectedIndex != -1)
                {
                    showMessageBox = true;
                    currentSelectTab = this.bwHoriTabcontrol1.TabCount - 1;
                    this.bwHoriTabcontrol1.SelectedIndex = this.bwHoriTabcontrol1.TabCount - 1;
                }
                else
                {
                    currentSelectTab += 1;
                    this.bwHoriTabcontrol1.SelectedIndex += 1;
                }
            }
            else if (this.ButtonNext.Text == "完成")
            {
                if (this.bwCheckBox3.Checked == false && this.comboBox12.SelectedIndex != -1)
                {
                    //加载压缩包内的内容。将压缩包内的内容读取到
                    String curfile = System.Reflection.Assembly.GetExecutingAssembly().Location;
                    String curDirectory = Path.GetDirectoryName(curfile);
                    String dir = curDirectory + "\\TX_Template";
                    string fileName = comboBox12.Text + ".zip";
                    String filePath = Path.Combine(dir, fileName);
                    if (File.Exists(filePath))
                    {
                        try
                        {

                            using (ZipInputStream s = new ZipInputStream(File.OpenRead(filePath)))
                            {
                                s.Password = "";  //解压密码
                                ZipEntry theEntry;

                                while ((theEntry = s.GetNextEntry()) != null)
                                {
                                    string uzFilePath = "";
                                    if (theEntry.Name == "TX_Option.xml" || theEntry.Name == "TX_FrameOption.frame")
                                    {
                                        uzFilePath = Path.Combine(curDirectory, theEntry.Name);
                                    }
                                    else
                                    {
                                        uzFilePath = Path.Combine(dir, theEntry.Name);
                                    }
                                    using (FileStream streamWriter = File.Create(uzFilePath))
                                    {
                                        int size = 2048;
                                        byte[] data = new byte[2048];
                                        while (true)
                                        {
                                            size = s.Read(data, 0, data.Length);

                                            if (size > 0)
                                                streamWriter.Write(data, 0, size);
                                            else
                                                break;
                                        }
                                        streamWriter.Close();
                                    }
                                }

                                s.Close();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }

                        #region oldCode 使用的是DotNetZip Dll
                        //using (ZipFile zip = ZipFile.Read(filePath))
                        //{

                        //    //foreach (ZipEntry en in zip)
                        //    //{
                        //    //    if (en.FileName == "TX_Option.xml" || en.FileName == "TX_FrameOption.frame")
                        //    //    {
                        //    //        en.Extract(curDirectory, ExtractExistingFileAction.OverwriteSilently);
                        //    //    }
                        //    //    else
                        //    //    {
                        //    //        en.Extract(dir, ExtractExistingFileAction.OverwriteSilently);
                        //    //        if (en.FileName == "HightWay.tx_hw")
                        //    //        {
                        //    //            string sourceFile = Path.Combine(dir, "HightWay.tx_hw");
                        //    //            string destinationFile = Path.Combine(dir, "高架总图.tx_高架总图");
                        //    //            if (File.Exists(destinationFile))
                        //    //            {
                        //    //                File.Replace(sourceFile, destinationFile, "HightWay.tx_hw.bak");
                        //    //                File.Delete("HightWay.tx_hw.bak");
                        //    //            }
                        //    //            else
                        //    //            {
                        //    //                File.Move(sourceFile, destinationFile);
                        //    //            }
                        //    //        }
                        //    //        else if (en.FileName == "DGContinueBeam.tx_dgcb")
                        //    //        {
                        //    //            string sourceFile = Path.Combine(dir, "DGContinueBeam.tx_dgcb");
                        //    //            string destinationFile = Path.Combine(dir, "等高连续梁.tx_等高连续梁");
                        //    //            if (File.Exists(destinationFile))
                        //    //            {
                        //    //                File.Replace(sourceFile, destinationFile, "DGContinueBeam.tx_dgcb.bak");
                        //    //                File.Delete("DGContinueBeam.tx_dgcb.bak");
                        //    //            }
                        //    //            else
                        //    //            {
                        //    //                File.Move(sourceFile, destinationFile);
                        //    //            }
                        //    //        }
                        //    //        else if (en.FileName == "BGContinueBeam.tx_bgcb")
                        //    //        {
                        //    //            string sourceFile = Path.Combine(dir, "BGContinueBeam.tx_bgcb");
                        //    //            string destinationFile = Path.Combine(dir, "变高连续梁.tx_变高连续梁");
                        //    //            if (File.Exists(destinationFile))
                        //    //            {
                        //    //                File.Replace(sourceFile, destinationFile, "BGContinueBeam.tx_bgcb.bak");
                        //    //                File.Delete("BGContinueBeam.tx_bgcb.bak");
                        //    //            }
                        //    //            else
                        //    //            {
                        //    //                File.Move(sourceFile, destinationFile);
                        //    //            }
                        //    //        }
                        //    //        else if (en.FileName == "XJContinueBeam.tx_xjcb")
                        //    //        {
                        //    //            string sourceFile = Path.Combine(dir, "XJContinueBeam.tx_xjcb");
                        //    //            string destinationFile = Path.Combine(dir, "悬浇连续梁.tx_悬浇连续梁");
                        //    //            if (File.Exists(destinationFile))
                        //    //            {
                        //    //                File.Replace(sourceFile, destinationFile, "XJContinueBeam.tx_xjcb.bak");
                        //    //                File.Delete("XJContinueBeam.tx_xjcb.bak");
                        //    //            }
                        //    //            else
                        //    //            {
                        //    //                File.Move(sourceFile, destinationFile);
                        //    //            }
                        //    //        }
                        //    //    }
                        //    //}
                        //}
                        #endregion
                    }
                    else
                    {
                        if (showMessageBox)
                        {
                            BWMessageBox.Show(this, "模板文件不存在", "提示", BWMessageBoxIcon.Information, BWMessageBoxButtons.OK);
                        }
                    }
                    this.Close();
                }
                else
                {
                    XmlRW.WriteToFile(this, map);  //存储数据。
                    this.Close();
                }
            }
        }

        private void SetDirectionForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            windowCloseCarton();
        }

        private void ButtonPre_Click(object sender, EventArgs e)
        {
            currentSelectTab -= 1;
            this.bwHoriTabcontrol1.SelectedIndex -= 1;
        }

        //初始化模板选项。模板选择的内容。
        //通过读取TX_Template下的zip文件。
        private void ModelInit()
        {
            String curFile = System.Reflection.Assembly.GetExecutingAssembly().Location;
            String curDirectory = Path.GetDirectoryName(curFile);
            String templateDir = Path.Combine(curDirectory, "TX_Template");
            string[] paths = Directory.GetFiles(templateDir);

            foreach (var file in paths)
            {
                string extension = Path.GetExtension(file).ToLower();
                if (extension == ".zip")
                {
                    string item = Path.GetFileNameWithoutExtension(file);
                    comboBox12.Items.Add(item);
                }
            }
        }

        private void comboBox15_SelectedIndexChanged(object sender, EventArgs e)
        {
            ShowImage(comboBox15);
        }

        private void comboBox15_MouseEnter(object sender, EventArgs e)
        {
            ShowImage(comboBox15);            
        }

        private void comboBox16_SelectedIndexChanged(object sender, EventArgs e)
        {
            ShowImage(comboBox16);
        }

        private void comboBox16_MouseEnter(object sender, EventArgs e)
        {
            ShowImage(comboBox16);
        }
    }

    //当向导界面上和软件界面内容不统一时采用SpecialMap
    class SpecialMap
    {
        public string wizard_CtrName = "";  //向导中控件的名字
        public string wizard_CtrValue = ""; //向导中控件的值转换成的string对象。
        public string fileCtrPath = "";   //特殊字符串 “||”前面表示文件路径，“||”后面表示XPath
        public string fileCtr_ModifyValue = "";  //这个表示需要更改的值

        public SpecialMap(string wizard_CtrName, string wizard_CtrValue, string fileCtr, string fileCtr_ModifyValue)
        {
            this.wizard_CtrName = wizard_CtrName;
            this.wizard_CtrValue = wizard_CtrValue;
            this.fileCtrPath = fileCtr;
            this.fileCtr_ModifyValue = fileCtr_ModifyValue;
        }
    }
}
